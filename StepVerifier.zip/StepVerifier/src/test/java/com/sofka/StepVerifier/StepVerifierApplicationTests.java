package com.sofka.StepVerifier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StepVerifierApplicationTests {

	@Test
	void contextLoads() {
	}

}
